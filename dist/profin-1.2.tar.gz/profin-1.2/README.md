# Model Purpose and General Information

This repository holds a Python package named pyproject, which can be used to conduct financial analysis
of energy projects.

Version 1.0 of this package was published on PyPI on 27/02/2024.

# Installation

# Workflow

# Testing
